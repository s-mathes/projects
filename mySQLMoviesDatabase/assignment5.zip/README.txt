To run code and build database, navigate to file folder in command line and 
execute 'python assignment5.py'.

'assignment5.py' contains the following instruction:
	sql = 'DROP DATABASE movies'
	curr.execute(sql)
on lines 16 and 17. Upon submission, they are commented out, and assumed that the 
MySQL database 'movies' does not exist. If this is not the case, remove the comment
formatters.

Database dump is in file 'Dump20200416.sql'

Writeup is in 'writeup.docx' and 'writeup.pdf'